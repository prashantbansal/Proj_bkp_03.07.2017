﻿
namespace ConsoleAppAll.MobileServiceLogsAnalysis
{
    class MSLAFileLog
    {
         public string FdN { get; set; }

        public string FN { get; set; }

        public string DnT { get; set; }

        public string URL { get; set; }

        public string UN { get; set; }

        public string Pwd { get; set; }

        public string EM { get; set; }

        public MSLAFileLog()
        {
            FdN = string.Empty;
            FN = string.Empty;
            DnT = string.Empty;
            URL = string.Empty;
            UN = string.Empty;
            Pwd = string.Empty;
            EM = string.Empty;
        }
    }
}
