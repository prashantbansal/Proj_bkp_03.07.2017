﻿using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace ConsoleAppAll.MobileServiceLogsAnalysis
{
    class MSLAFileReader
    {
        public string ParentFolderPath { get; set; }

        private List<MSLAFileLog> _fileLogList;

        public List<MSLAFileLog> FileLogList
        {
            get
            {
                if (_fileLogList == null)
                {
                    _fileLogList = new List<MSLAFileLog>();
                }
                return _fileLogList;
            }
            set
            {
                _fileLogList = value;
            }
        }

        public void ReadLogs(string path)
        {
            ParentFolderPath = path;

            ValidatePathExists();

            ReadFileLogs();

            Console.WriteLine("--------------All files are parsed successfully------------------");
        }

        private void SaveToDisk(string fileName)
        {
            try
            {
                if (FileLogList != null && FileLogList.Count > 0)
                {
                    string folderPathToBeSaved = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);

                    ////this.SaveToExcel(folderPathToBeSaved, fileName);

                    //System.Xml.Serialization.XmlSerializer writer =
                    //    new System.Xml.Serialization.XmlSerializer(typeof(List<FileLog>));

                    //System.IO.StreamWriter file = new System.IO.StreamWriter(folderPathToBeSaved + @"\\" + fileName + ".xml");
                    //writer.Serialize(file, this.FileLogList);
                    //file.Close();

                    SaveToExcel(folderPathToBeSaved, fileName);

                    FileLogList.Clear();
                    Console.WriteLine("File is saved on your desktop as " + fileName + ".xlsx");
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void ValidatePathExists()
        {
            if (!Directory.Exists(ParentFolderPath))
            {
                throw new Exception("ERROR: Folder not found at the given path");
            }
            Console.WriteLine("Folder found. Log files reading in process..");
        }

        private void ReadFileLogs()
        {
            var directoryList = Directory.EnumerateDirectories(ParentFolderPath, "*.*");

            if (directoryList.Any())
            {
                Console.WriteLine();
                Console.WriteLine("Total Folders found:" + directoryList.Count());

                foreach (var row in directoryList)
                {
                    ReadFolder(row);
                    //DirectoryInfo dir = new DirectoryInfo(row);
                    //this.SaveToDisk(dir.Name);
                }

                SaveToDisk("LogFiles");
            }
        }

        private void ReadFolder(string folderPath)
        {
            DirectoryInfo dir = new DirectoryInfo(folderPath);
            Console.WriteLine("-----------------Folder:" + dir.Name + "--------------");

            var fileList = Directory.EnumerateFiles(folderPath, "*.*");

            if (fileList.Any())
            {
                Console.WriteLine("Total Files found:" + fileList.Count().ToString());

                foreach (var file in fileList)
                {
                    ReadFile(file);
                }
            }
        }

        private void ReadFile(string filePath)
        {
            try
            {
                FileInfo fileInfo = new FileInfo(filePath);
                Console.WriteLine("Reading:" + fileInfo.Name);
                string[] alllines = null;

                alllines = File.ReadAllLines(filePath);

                MSLAFileLog fileLog = new MSLAFileLog();

                foreach (var line in alllines)
                {
                    try
                    {
                        if (line.Contains(@"http://kbr.kaplan.com/services/login") || line.Contains(@"http://kbrarc.kaplan.com/services/login"))
                        {
                            fileLog = new MSLAFileLog();
                            var lineSplit = line.Split(' ');
                            if (lineSplit.Length > 1)
                            {
                                fileLog.DnT = lineSplit.First() + " " + lineSplit[1].Split(',')[0];
                                var loginUrl = lineSplit.First(x => x.Contains(@"kaplan.com/services"));
                                //fileLog.URL = loginURL;

                                fileLog.UN = loginUrl.Split('/')[5];
                                fileLog.Pwd = loginUrl.Split('/')[6].Replace("v2?password=", string.Empty);

                                fileLog.FdN = fileInfo.Directory.Name;

                                fileLog.FN = fileInfo.Name;
                            }
                        }

                        if (line.Contains("System.Exception:"))
                        {
                            fileLog.EM = line.Split(':')[1].Replace("You do not have active enrollments.", "101").Trim();

                            if (!string.IsNullOrEmpty(fileLog.FN))
                            {
                                FileLogList.Add(fileLog);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void SaveToExcel(string filePath, string fileName)
        {
            string fileSavePath = string.Format("{0}\\{1}.xlsx", filePath, fileName);
            FileInfo newFile = new FileInfo(fileSavePath);

            using (ExcelPackage xlPackage = new ExcelPackage(newFile))
            {
                ExcelWorksheet worksheet = xlPackage.Workbook.Worksheets.Add("UsersList");

                worksheet.Cells[1, 1].Value = "FolderName";
                worksheet.Cells[1, 2].Value = "FileName";
                worksheet.Cells[1, 3].Value = "DateAndTime";
                worksheet.Cells[1, 4].Value = "URL";
                worksheet.Cells[1, 5].Value = "UserName";
                worksheet.Cells[1, 6].Value = "Password";
                worksheet.Cells[1, 7].Value = "ErrorMessage";

                // write some titles into column 1
                for (int i = 0; i < FileLogList.Count; i++)
                {
                    worksheet.Cells[i + 2, 1].Value = FileLogList[i].FdN;
                    worksheet.Cells[i + 2, 2].Value = FileLogList[i].FN;
                    worksheet.Cells[i + 2, 3].Value = FileLogList[i].DnT;
                    worksheet.Cells[i + 2, 4].Value = FileLogList[i].URL;
                    worksheet.Cells[i + 2, 5].Value = FileLogList[i].UN;
                    worksheet.Cells[i + 2, 6].Value = FileLogList[i].Pwd;
                    worksheet.Cells[i + 2, 7].Value = FileLogList[i].EM;
                }

                xlPackage.Save();
            }
        }
    }
}
