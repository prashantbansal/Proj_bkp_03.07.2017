﻿using System;

namespace ConsoleAppAll.MobileServiceLogsAnalysis
{
    class MSLAUserInput
    {
        public void StartProcess()
        {
            try
            {
                Console.WriteLine("Provide the path of logs");
                //var response = Console.ReadLine();

                var response = @"D:\Kaplan\Documents\Production Logs\Service_Logs_11_24_2015";
                Console.WriteLine("Path Provided:" + response);
                Console.WriteLine();

                MSLAFileReader fileReader = new MSLAFileReader();
                fileReader.ReadLogs(response);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
