﻿using System;

namespace ConsoleAppAll
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            try
            {
                GenericUserInput.DisplayFunctionalityList();
                GenericUserInput.ValidateUserInput();
                Console.ReadLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine("---------------Exception thrown-------------");
                Console.WriteLine(ex.Message);
                Console.ReadLine();
            }  
        }

    }
}
