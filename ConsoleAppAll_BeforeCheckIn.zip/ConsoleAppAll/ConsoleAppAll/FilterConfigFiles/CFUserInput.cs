﻿using System;

namespace ConsoleAppAll.FilterConfigFiles

{
    public class CFUserInput
    {
        internal void StartProcess()
        {
            try
            {
                Console.WriteLine("Provide the path of Code Base");
                //var response = Console.ReadLine();

                var codeBaseResponse = @"D:\Kaplan\Documents\Configs\CodeBase\KBR_101";

                Console.WriteLine("Path Provided:" + codeBaseResponse);
                Console.WriteLine();

                Console.WriteLine("Provide the path of Filtered Configurations");
                //var response = Console.ReadLine();

                var filteredPathResponse = @"D:\Kaplan\Documents\Configs\FilteredConfigurations";
                Console.WriteLine("Path Provided:" + filteredPathResponse);
                Console.WriteLine();

                CFFileReader fileReader = new CFFileReader();
                fileReader.ReadFiles(codeBaseResponse, filteredPathResponse);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
