﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace ConsoleAppAll.FilterConfigFiles
{
    public class CFFileReader
    {
        public string CodeBasePath { get; set; }
        public string FilteredConfigurationPath { get; set; }

        public void ReadFiles(string fromPath, string toPath)
        {
            CodeBasePath = fromPath;
            FilteredConfigurationPath = toPath;

            ValidatePathExists();

            ReadFolders();

            Console.WriteLine("--------------All files are copied successfully------------------");
        }

        private void ValidatePathExists()
        {
            if (!Directory.Exists(CodeBasePath))
            {
                throw new Exception("ERROR: Code Folder not found at the given path");
            }

            if (!Directory.Exists(FilteredConfigurationPath))
            {
                throw new Exception("ERROR: Filtered Configuration Folder not found at the given path");
            }

            Console.WriteLine("Folder found. Files reading in process..");
        }

        private void ReadFolders()
        {
            DirectoryInfo dir = new DirectoryInfo(CodeBasePath);

            List<string> fileList = Directory.EnumerateFiles(CodeBasePath, "*.Config", SearchOption.AllDirectories).ToList();

            FilteredConfigurationPath = FilteredConfigurationPath + "\\" + dir.Name;
            if (!Directory.Exists(FilteredConfigurationPath))
            {
                Directory.CreateDirectory(FilteredConfigurationPath);
            }
            foreach (var row in fileList)
            {
                string path = row;
                path = path.Replace(CodeBasePath, FilteredConfigurationPath);

                var fileInner = new FileInfo(path);

                if (!Directory.Exists(fileInner.Directory.FullName))
                {
                    Directory.CreateDirectory(fileInner.Directory.FullName);
                }

                File.Copy(row, path, true);
            }
        }
    }
}
