﻿using ConsoleAppAll.FilterConfigFiles;
using System;
using ConsoleAppAll.MobileServiceLogsAnalysis;

namespace ConsoleAppAll
{
    public class GenericUserInput
    {
        private static readonly string[][] FunctionalityList = new[]
        {
            new[] {"1", "Filter the Configurations from code base."},
            new[] {"2", "Read the Log files and generate CSV from it."}
        };

        internal static void DisplayFunctionalityList()
        {
            Console.WriteLine("-----------------Execution Criteria List------------------");
            Console.WriteLine();
            foreach (var row in FunctionalityList)
            {
                Console.WriteLine("{0}:  {1}", row[0], row[1]);              
            }

            Console.WriteLine();
            Console.WriteLine("----------------------------------------------------------");
            Console.WriteLine();
        }

        internal static void ValidateUserInput()
        {
            int maxInputCount = FunctionalityList.Length;
            string response;
            int userInputKey;

            do
            {
                Console.WriteLine("Enter your criterion below");
                response = Console.ReadLine();
            } while (!(int.TryParse(response, out userInputKey) && userInputKey > 0 && userInputKey <= maxInputCount));

            StartTheFunctionality(userInputKey);
        }

        private static void StartTheFunctionality(int userInput)
        {
            Console.Clear();
            switch (userInput)
            {
                case 1:
                    FilterConfiguration();
                    break;
                case 2:
                    MobileServiceLogAnalysis();
                    break;
                default:
                    throw new Exception("Functionality not found for criteria:" + userInput.ToString());
            }
        }

        /// <summary>
        /// This function is used to read the entire code base and then filter out only "*.config" files 
        /// and move it to another folder with proper hierarchy
        /// The path for Code base and where configurations have to be copied is input in Console
        /// </summary>
        private static void FilterConfiguration()
        {
            try
            {
                CFUserInput cfuserInput = new CFUserInput();
                cfuserInput.StartProcess();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

       /// <summary>
       /// This function is to read the logs for service file and generate a excel file from it
       /// </summary>
        private static void MobileServiceLogAnalysis()
        {
            try
            {
                MSLAUserInput mslaUserInput = new MSLAUserInput();
                mslaUserInput.StartProcess();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
