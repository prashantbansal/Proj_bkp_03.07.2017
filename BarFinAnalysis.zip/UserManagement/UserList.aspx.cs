﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI.WebControls;
using BFA.Business;
using BFA.Entity;

namespace BarFinAnalysis.UserManagement
{
    public partial class UserList : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ((BarFinAnalysisMaster)Page.Master).PageTitle = "User List";
                BindUserList();
            }
        }

        private void BindUserList()
        {
            BLL_User bll = new BLL_User();
            List<User> userList = bll.GetUserList().ToList();

            if (userList.Any())
            {
                gvUserList.DataSource = userList;
                gvUserList.DataBind();
            }
        }

        protected void btnNewUser_OnClick(object sender, EventArgs e)
        {
            Response.Redirect("~/UserManagement/Profile.aspx?UserId=-1", true);
        }

        //protected void dvUserList_OnRowCommand(object sender, GridViewCommandEventArgs e)
        //{
        //    switch (e.CommandName)
        //    {
        //        case "cEdit":
        //            Response.Redirect(
        //                "~Manage/UserProfile.aspx?UserId=" + dvUserList.DataKeys[Convert.ToInt32(e.CommandArgument)].Values[0],
        //                true);
        //            break;
        //    }
        //}

        protected void dvUserList_OnSorting(object sender, GridViewSortEventArgs e)
        {
            throw new NotImplementedException();
        }
    }
}