﻿using System;
using BFA.Business;
using BFA.Entity;
using BFA.Entity.Enumerations;

namespace BarFinAnalysis.UserManagement
{
    public partial class Profile : Page_Base
    {
        private int RequestedUserId
        {
            get
            {
                if (Request.QueryString["UserId"] != null)
                {
                    return Convert.ToInt32(Request.QueryString["UserId"]);
                }
                return CurrentUser.UserId;
            }
        }

        private bool IsMyProfileEdit
        {
            get
            {
                if (Request.QueryString["UserId"] != null)
                {
                    return false;
                }
                return true;
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ((BarFinAnalysisMaster) Page.Master).PageTitle = IsMyProfileEdit ? "My Profile" : "User Profile";

                BindUserDetails(RequestedUserId);
                ToggleControls();
            }
        }

        private void BindUserDetails(int userId)
        {
            if (userId <= 0) 
                return;

            BLL_User bll = new BLL_User();
            User user = bll.GetUserDetails(userId);

            if (user != null)
            {
                lblUserId.Text = user.UserId.ToString();
                txtFirstName.Text = user.FirstName;
                txtLastName.Text = user.LastName;
                txtExternalId.Text = user.ExternalId;
                txtEmail.Text = user.Email;
                txtUserName.Text = user.UserName;
                txtPassword.Text = user.Password;
                ddlRoles.SelectedValue = ((int)user.RoleType).ToString();
                lblRole.Text = user.RoleType.ToString();
                chkActive.Checked = user.UserStatus == UserStatus.Active;
            }
        }

        private void ToggleControls()
        {
            txtUserName.Enabled = !IsMyProfileEdit;
            ddlRoles.Visible = !IsMyProfileEdit;
            lblRole.Visible = IsMyProfileEdit;
            txtFirstName.Enabled = !IsMyProfileEdit;
            txtLastName.Enabled = !IsMyProfileEdit;
            txtEmail.Enabled = !IsMyProfileEdit;
            txtExternalId.Enabled = !IsMyProfileEdit;
            dvActive.Visible = !IsMyProfileEdit;
        }

        private bool Confirm()
        {
            if (string.IsNullOrEmpty(txtLastName.Text))
            {
                lblErrorMessage.Text = "Last Name can't be empty";
                return false;
            }
            if (string.IsNullOrEmpty(txtEmail.Text))
            {
                lblErrorMessage.Text = "Email can't be empty";
                return false;
            }
            if (string.IsNullOrEmpty(txtUserName.Text))
            {
                lblErrorMessage.Text = "UserName can't be empty";
                return false;
            }
            if (string.IsNullOrEmpty(txtPassword.Text))
            {
                lblErrorMessage.Text = "Password can't be empty";
                return false;
            }
            if (string.IsNullOrEmpty(txtExternalId.Text))
            {
                lblErrorMessage.Text = "External Id can't be empty";
                return false;
            }

            return true;
        }

        protected void btnSaveProfile_Click(object sender, EventArgs e)
        {
            try
            {
                lblErrorMessage.Visible = false;
                
                if (!Confirm())
                {
                    lblErrorMessage.Visible = true;
                    return;
                }

                User user = new User
                {
                    UserId = Convert.ToInt32(lblUserId.Text),
                    FirstName = txtFirstName.Text.Trim(),
                    LastName = txtLastName.Text.Trim(),
                    ExternalId = txtExternalId.Text.Trim(),
                    UserName = txtUserName.Text.Trim(),
                    Email = txtEmail.Text.Trim(),
                    Password = txtPassword.Text.Trim(),
                    RoleType = (RoleType) Convert.ToInt32(ddlRoles.SelectedValue),
                    UserStatus = chkActive.Checked ? UserStatus.Active : UserStatus.Inactive
                };

                BLL_User bll=new BLL_User();
                int userId = bll.UpdateUserDetails(user);
                lblUserId.Text = userId.ToString();

                Response.Redirect("UserList.aspx", true);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}