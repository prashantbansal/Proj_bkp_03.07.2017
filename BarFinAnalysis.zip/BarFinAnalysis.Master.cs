﻿using System;
using BFA.Entity.Enumerations;

namespace BarFinAnalysis
{
    public partial class BarFinAnalysisMaster : Master_Base
    {
        public string PageTitle
        {
            get { return lblPageTitle.Text; }
            set { lblPageTitle.Text = value; }
        }

        protected void Page_Init(object sender, EventArgs e)
        {
            liUserManagement.Visible = (CurrentUser.RoleType == RoleType.Admin);
        }

        protected void master_Page_PreLoad(object sender, EventArgs e)
        {
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            
        }
    }
}