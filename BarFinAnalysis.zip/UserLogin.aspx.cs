﻿using System;
using System.CodeDom;
using System.Data.SqlClient;
using System.Web.Management;
using System.Web.UI;
using BFA.Business;
using BFA.Entity;
using BFA.Utility;

namespace BarFinAnalysis
{
    public partial class UserLogin : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                Session.Abandon();
                UserName.Focus();
            }
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
             try
            {
                BLL_User bll = new BLL_User();
                UserSession userResponse = bll.GetLoggedInUserInformation(UserName.Text.Trim(), Password.Text.Trim());
                if (userResponse != null && userResponse.UserId > 0)
                {
                    SessionManager.SetSession(SessionKeys.UserSessionKey, userResponse);
                    Response.Redirect("~/Reports/UserRegistrationReport.aspx", true);
                }
            }
            catch (Exception ex)
            {
                if (ex is SqlException)
                {
                    if (ex.Message.Contains("10001"))
                    {
                        lblUserMessage.Text = "Invalid username or password";
                        return;
                    }
                }
                lblUserMessage.Text = ex.Message;
            }
        }
    }
}