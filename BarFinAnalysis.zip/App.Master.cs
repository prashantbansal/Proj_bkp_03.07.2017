﻿using System;
using System.Web.UI;

namespace BarFinAnalysis
{
    public partial class AppMaster : MasterPage
    {
        protected void Page_Init(object sender, EventArgs e)
        {

        }

        protected void master_Page_PreLoad(object sender, EventArgs e)
        {
        }

        protected void Page_Load(object sender, EventArgs e)
        {
           
        }
    }
}