﻿using System.Web.UI;
using BFA.Entity;
using BFA.Utility;

namespace BarFinAnalysis
{
    public class Master_Base: MasterPage
    {
        private UserSession _currentUser;
        public UserSession CurrentUser
        {
            get
            {
                if (_currentUser != null)
                {
                    return _currentUser;
                }
                else
                {
                    _currentUser = SessionManager.GetSession<UserSession>(SessionKeys.UserSessionKey);
                }
                return _currentUser;
            }
        }
    }
}