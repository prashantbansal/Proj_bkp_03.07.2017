﻿using System;
using System.Web.UI;
using BFA.Entity;
using BFA.Entity.Enumerations;
using BFA.Utility;

namespace BarFinAnalysis
{
    public class Page_Base: Page
    {
        private UserSession _currentUser;
        protected UserSession CurrentUser
        {
            get
            {
                if (_currentUser != null)
                {
                    return _currentUser;
                }
                else
                {
                    _currentUser = SessionManager.GetSession<UserSession>(SessionKeys.UserSessionKey);
                }
                return _currentUser;
            }
            set { _currentUser = value; }
        }

        protected bool IsAdmin
        {
            get { return CurrentUser.RoleType == RoleType.Admin; }
        }

        protected override void OnPreInit(EventArgs e)
        {
            base.OnPreInit(e);

            CheckSession();
        }

        private void CheckSession()
        {
            object o = CurrentUser;
            if (o == null)
            {
                Response.Redirect("~/UserLogin.aspx", true);
            }
        }
    }
}