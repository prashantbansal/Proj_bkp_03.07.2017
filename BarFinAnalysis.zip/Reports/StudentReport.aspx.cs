﻿using System;
using System.Collections.Generic;
using System.Linq;
using BFA.Business;
using BFA.Entity;

namespace BarFinAnalysis.Reports
{
    public partial class StudentReport : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindUserList();
            }
        }

        private void BindUserList()
        {
            BLL_User bll = new BLL_User();
            List<User> userList = bll.GetUserList().ToList();

            if (userList.Any())
            {
                ddlUserList.DataSource = userList;
                ddlUserList.DataValueField = "ExternalId";
                ddlUserList.DataTextField = "UserName";
                ddlUserList.DataBind();
            }
        }

        protected void btnGetStudentReport_OnClick(object sender, EventArgs e)
        {
            BLL_Report bll = new BLL_Report();
            var response = bll.GetStudentReport(ddlUserList.SelectedValue, Convert.ToDateTime(txtStartDate.Text), Convert.ToDateTime(txtEndDate.Text));

            if (response.Any())
            {
                gvStudentReport.DataSource = response;
                gvStudentReport.DataBind();
            }
        }
    }
}