﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web.UI.WebControls;
using BFA.Business;
using BFA.Entity;
using BFA.Entity.Enumerations;

namespace BarFinAnalysis.Reports
{
    public partial class UserRegistrationReport : Page_Base
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ((BarFinAnalysisMaster)Page.Master).PageTitle = "Registration Report";

                if (IsAdmin)
                {
                    dvUserList.Visible = true;
                    BindUserList();
                    ToggleReportMessage("Select your filter criteria.");
                }
                PopulateDefaultData();
            }
        }

        private void PopulateDefaultData()
        {
            txtEndDate.Text = DateTime.Now.ToString("MM/dd/yyyy");
            DateTime schoolDateStart = Convert.ToDateTime(string.Format("1-Jul-{0}", DateTime.Now.Year));
            txtStartDate.Text = schoolDateStart > DateTime.Now ? schoolDateStart.AddYears(-1).ToString("MM/dd/yyyy") : 
                schoolDateStart.ToString("MM/dd/yyyy");
        }

        private void BindUserList()
        {
            BLL_User bll = new BLL_User();
            List<User> userList = bll.GetUserList().Where(x=>x.RoleType==RoleType.Representative).ToList();

            List<Tuple<string, string>> customUserList = new List<Tuple<string, string>>();
            foreach (var user in userList)
            {
                customUserList.Add(new Tuple<string, string>(user.ExternalId,
                    user.FirstName + " " + user.LastName + " | " + user.ExternalId));
            }

            if (userList.Any())
            {
                ddlUserList.DataSource = customUserList.OrderBy(x => x.Item2);
                ddlUserList.DataValueField = "Item1";
                ddlUserList.DataTextField = "Item2";
                ddlUserList.DataBind();
            }
        }

        private bool Validate()
        {
            DateTime userInput;
            if (!DateTime.TryParseExact(txtStartDate.Text, "MM/dd/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out userInput))
            {
                ToggleReportMessage("Start Date is not in valid format.");
                return false;
            }
            else if (!DateTime.TryParseExact(txtEndDate.Text,"MM/dd/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out userInput))
            {
                ToggleReportMessage("End Date is not in valid format.");
                return false;
            }
            return true;
        }

        protected void btnGetUserRegistrationReport_OnClick(object sender, EventArgs e)
        {
            try
            {
                if (Validate())
                {
                    string externalId = IsAdmin ? ddlUserList.SelectedValue : CurrentUser.ExternalId;

                    BLL_Report bll = new BLL_Report();
                    var reportResults = bll.GetStudentReport(externalId, Convert.ToDateTime(txtStartDate.Text),
                        Convert.ToDateTime(txtEndDate.Text));

                    if (reportResults.Any())
                    {
                        dvReport.Visible = true;
                        ToggleReportMessage(string.Empty);
                        gvStudentReport.DataSource = reportResults;
                        gvStudentReport.DataBind();
                    }
                    else
                    {
                        ToggleReportMessage("No records found.");
                    }
                }
            }
            catch (Exception ex)
            {
                ToggleReportMessage(ex.Message);
            }
        }

        private void ToggleReportMessage(string message)
        {
            lblReportMessage.Text = message;
            lblReportMessage.Visible = !string.IsNullOrEmpty(message);
            dvReport.Visible = string.IsNullOrEmpty(message);
        }
    }
}